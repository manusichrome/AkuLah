'use strict';

// DB
const { listCommands } = require('../../stores/command');

const { scheduleDeletion } = require('../../utils/tg');

const commandReference = `\
<b>🔐 Master commands</b>:
/admin - Makes the user admin.
/unadmin - Demotes the user from admin list.
/leave &lt;name|id&gt; - Makes the bot leave the group cleanly.
/hidegroup - Hide the group from /groups list.
/showgroup - Show the group it in /groups list.

<b>👤Admin commands</b>:
/warn &lt;reason&gt; - Warns the user.
/unwarn - Removes the last warn from the user.
/nowarns - Clears warns for the user.
/ban &lt;reason&gt; - Bans the user from groups.
/unban - Removes the user from ban list.
/user - Shows user's status and warns.
/addcommand &lt;name&gt; - to create a custom command.
/removecommand &lt;name&gt; - to remove a custom command.

<b>🌏 Commands for everyone</b>:
/staff - Shows a list of admins.
/about - Shows about us.
/link - Show the current group's link.
/groups - Show a list of groups which the bot is admin in.
/report - Reports the replied-to message to admins.
`;

const commandReferenceHandler = async ({ replyWithHTML }) => {
	const customCommands = await listCommands();
	const customCommandsText = customCommands.length
		? '\n<b>Custom commands:</b>\n' +
		customCommands
			.filter(command => command.isActive)
			.sort((a, b) => a.role.toLowerCase() < b.role.toLowerCase())
			.map(command =>
				`[${command.role.toLowerCase()}] ` +
				`<code>!${command.name}</code>`)
			.join('\n')
		: '';
	return replyWithHTML(commandReference + customCommandsText)
		.then(scheduleDeletion);
};

module.exports = commandReferenceHandler;
