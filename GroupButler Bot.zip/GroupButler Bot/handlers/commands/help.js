'use strict';
const { Markup, Extra } = require('telegraf');
const { contactme } = require('../../package.json');
const { channel } = require('../../package.json');
const { rateme } = require('../../package.json');



const message = `\
Hey there!, Nice To Meet You

This is <a href="https://t.me/scriptmarketbot">GroupButler</a> bot. \
I'm an <b>administration</b> bot that helps you to keep \
your <b>groups</b> safe from <b>spammers.</b> 

<b>I can do a lot of cool stuffs,</b> here's a short list:
• I can <b>kick or ban</b> users
• You can use me to set the group rules
• I have a flexible <b>anti-flood</b> system
• I can <b>warn</b> users, and ban them when they reach the maximum number of warnings
• I can also <b>warn, kick or ban</b> users when they post a specific media
…and more, below you can find the "all commands" button to get the whole list!

`;

const helpHandler = ({ chat, replyWithHTML }) => {
	if (chat.type !== 'private') return null;

	return replyWithHTML(
		message,
		Markup.inlineKeyboard([
			[Markup.urlButton('📢 News Channel', channel), Markup.urlButton('👥 Group', 'https://t.me/nameyourgroup'),  Markup.urlButton('🏆 Rate Me!', rateme)
		],
    [Markup.urlButton('🤖 Bot Monitoring', 'https://t.me/bmonitoringbot'),  Markup.urlButton('👤 Contact Me', contactme)]
		]).extra()
	);
};

module.exports = helpHandler;
