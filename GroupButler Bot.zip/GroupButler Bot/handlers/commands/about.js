'use strict';
const { Markup } = require('telegraf');
const { contactme } = require('../../package.json');
const { channel } = require('../../package.json');
const { rateme } = require('../../package.json');

const message = `\
Hey there!

This is <a href="https://t.me/scriptmarketbot">GroupButler</a> bot. \
I'm an <b>administration</b> bot that helps you to keep \
your <b>groups</b> safe from <b>spammers.</b> \
Developed and hosted by @manusii. Has been customized for Bot Monitoring Group and it's affiliations. 

Send /commands to get the list of available commands. \
If you want to use me for your groups, \
note that I'm more useful on a network of groups

So if you only need to manage a single group, @GroupButler_bot \
and @mattatabot might be better choices for you.
`;

const helpHandler = ({ chat, replyWithHTML }) => {
	if (chat.type !== 'private') return null;

	return replyWithHTML(
		message,
		Markup.inlineKeyboard([
			[Markup.urlButton('📢 News Channel', channel), Markup.urlButton('👥 Group', 'https://t.me/nameyourgroup'),  Markup.urlButton('🏆 Rate Me!', rateme)
		],
    [Markup.urlButton('🤖 Bot Monitoring', 'https://t.me/bmonitoringbot'),  Markup.urlButton('👤 Contact Me', contactme)]
		]).extra()
	);
};

module.exports = helpHandler;
