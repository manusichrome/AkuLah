'use strict';

// "clone" the function (https://stackoverflow.com/a/6772648)
module.exports = require('./help').bind();
