'use strict';

const username = s => s.replace(/^@/, '').toLowerCase();

module.exports = {
	username,
};
